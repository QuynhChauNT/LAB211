package week04.manage_students;

import java.util.Scanner;

public class Utilizer {

    static String isValidCourse() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            try {
                String input = scanner.next();
                if (input.equalsIgnoreCase("java") || input.equalsIgnoreCase("c++") || input.equalsIgnoreCase(".net")) {
                    return input;
                } else {
                    System.out.println("Invalid course! Please enter Java, C++, or .NET.");
                }
            } catch (Exception e) {
                System.out.println("error! please try again.");
                scanner.next();
            }
        }
    }
}
