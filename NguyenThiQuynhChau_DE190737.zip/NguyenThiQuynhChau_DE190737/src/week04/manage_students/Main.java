package week04.manage_students;

public class Main {
    

    public static void main(String[] args) {
        StudentManagerment sm = new StudentManagerment();
        sm.mainMenu();
    }
}
