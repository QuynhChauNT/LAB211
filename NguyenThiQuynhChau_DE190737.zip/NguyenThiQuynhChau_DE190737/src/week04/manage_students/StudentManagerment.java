package week04.manage_students;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class StudentManagerment {

    Scanner sc = new Scanner(System.in);
    private List<Students> studentList = new ArrayList<>();
    Students students = new Students();

    public void addStudent() {
        System.out.println("input student id: ");
        String id = sc.nextLine();
        System.out.println("input student name: ");
        String name = sc.nextLine();
        System.out.println("input semester: ");
        String semester = sc.nextLine();
        System.out.println("input course name(java/c++/.net):");
        String course = Utilizer.isValidCourse();

        Students st = new Students(id, name, course, semester);

        studentList.add(st);
        System.out.println("Student added successfully!");
    }

    public void showStudent() {
        for (Students st : studentList) {
            System.out.println(st.toString());
        }

    }

    public List<Students> findStudent(String name) {
        List<Students> foundStudents = new ArrayList<>();
        for (Students st : studentList) {
            if (st.getStName().toLowerCase().contains(name.toLowerCase())) {
                foundStudents.add(st);
            }
        }
        return foundStudents;
    }

    public void sortStudents() {
        Collections.sort(studentList, new Comparator<Students>() {
            @Override
            public int compare(Students st1, Students st2) {
                return st1.getStName().compareTo(st2.getStName());
            }
        });

    }

    public void updateStudent(Students st) {
        System.out.print("Input new name: ");
        st.setStName(sc.nextLine());
        System.out.print("Input new semester: ");
        st.setSemester(sc.nextLine());
        System.out.print("Input new course (Java/C++/.Net): ");
        st.setCourse(sc.nextLine());
        System.out.println("Student updated successfully!");
    }

    public void deleteStudent(Students st) {
        studentList.remove(st);
        System.out.println("remove successfully!");
    }

    public void reportStudents() {
        Map<String, Integer> ds = new HashMap<>();
        for (Students st : studentList) {
            String key = st.getStudentId() + " | " + st.getStName() + " | " + st.getCourse();
            ds.put(key, ds.getOrDefault(key, 0) + 1);
        }

        for (Map.Entry<String, Integer> infor : ds.entrySet()) {
            System.out.println(infor.getKey() + " | " + infor.getValue());
        }
    }

    public void mainMenu() {
        while (true) {
            System.out.println("\nWELCOME TO STUDENT MANAGEMENT");
            System.out.println("1. Create");
            System.out.println("2. Find and Sort");
            System.out.println("3. Update/Delete");
            System.out.println("4. Report");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            int choice = sc.nextInt();
            sc.nextLine();
            switch (choice) {
                case 1:
                    addStudent();
                    break;
                case 2:
                    System.out.print("Enter student name to search: ");
                    String name = sc.nextLine();
                    List<Students> found = findStudent(name);

//                    System.out.println(findStudent(name));
                    if (found.isEmpty()) {
                        System.out.println("No students found with the name: " + name);
                    } else {
                        System.out.println("Found students:");
                        for (Students s : found) {
                            System.out.println(s);
                        }
                        System.out.println("After sort student by name");
                        sortStudents();
                        showStudent();
                    }
                    break;
                case 3:
                    System.out.print("Enter student ID to find: ");
                    String id = sc.nextLine();
                    boolean foundStudent = false;

                    Iterator<Students> iterator = studentList.iterator();
                    while (iterator.hasNext()) {
                        Students st = iterator.next();
                        if (st.getStudentId().equalsIgnoreCase(id)) {
                            foundStudent = true;
                            System.out.println("Do you want to update (U) or delete (D) the student?");
                            String n = sc.nextLine();
                            if (n.equalsIgnoreCase("U")) {
                                updateStudent(st);
                            } else if (n.equalsIgnoreCase("D")) {
                                iterator.remove(); 
                                System.out.println("Student removed successfully!");
                            }
                            break; 
                        }
                    }
                    if (!foundStudent) {
                        System.out.println("Student not found!");
                    }

                case 4:
                    reportStudents();
                    break;
                case 5:
                    System.out.println("Exiting program...");
                    return;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }

}
