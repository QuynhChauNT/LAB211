package week04.manage_students;

public class Students {
    private String studentId;
    private String stName;
    private String course;
    private String semester;

    public Students() {
    }

    public Students( String studentId, String stName, String course, String semester) {
        this.stName = stName;
        this.course = course;
        this.studentId = studentId;
        this.semester = semester;
    }

    public String getStName() {
        return stName;
    }

    public void setStName(String stName) {
        this.stName = stName;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }
    
    @Override
    public String toString() {
        return String.format("%-5s | %-20s | %-8s | %-5s",this.studentId, this.stName, this.course, this.semester);
    }
    
}
