package week03.bubble_sort_algorithm;

import java.util.Random;

public class MangSoNguyen {

    private int[] array;

    public MangSoNguyen(int m) {
        this.array = new int[m];
    }
    
    public void addValue(){
        Random random = new Random();
        for (int i=0; i< this.array.length; i++){
            this.array[i] = random.nextInt(this.array.length);
        }
    }
    
    public void showValue(){
        for (int i=0; i<this.array.length; i++){
            System.out.print(this.array[i] + "    ");
        }
        System.out.println();
    }

    public void sortValue(){
        boolean check = false;  // check nếu không swap thì k cần chạy for
        for (int i=0; i < this.array.length-1 && !check; i++){
            check = true;
            for (int j=0; j < this.array.length - i - 1; j++){
                if (this.array[j] > this.array[j+1]){
                    int temp = this.array[j];
                    this.array[j] = this.array[j+1];
                    this.array[j + 1] = temp;
                    check = false;
                }
            }
        }
    }
}
