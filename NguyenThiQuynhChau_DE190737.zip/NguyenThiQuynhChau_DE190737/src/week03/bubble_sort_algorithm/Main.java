package week03.bubble_sort_algorithm;


public class Main {
    public static void main(String[] args) {
        int m = Utilizer.checkNumber();
        MangSoNguyen mangSoNguyen = new MangSoNguyen(m);
        mangSoNguyen.addValue();
        mangSoNguyen.showValue();
        mangSoNguyen.sortValue();
        mangSoNguyen.showValue();
    }
}
