package week03.bubble_sort_algorithm;

import java.util.Scanner;

public class Utilizer {

    public static int checkNumber() {
        Scanner sc = new Scanner(System.in);
        while (true) {
            try {
                System.out.print("Enter a number: ");
                int input = Integer.parseInt(sc.nextLine());
                if (input >= 2) return input;
                System.out.println("Error. Number must be ≥ 2. Please enter again!");
            } catch (Exception e) {
                System.out.println("Error. Please enter again!");
            }
        }
    }
}
