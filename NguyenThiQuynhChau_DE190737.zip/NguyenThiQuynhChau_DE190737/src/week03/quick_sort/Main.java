package week03.quick_sort;
public class Main {
    public static void main(String[] args) {
        QuickSort qs = new QuickSort(Utilizer.limitedNumber());
        qs.addValue();
        System.out.println("Array before sort: ");
        qs.showValue();
        
        System.out.println("After sort: ");
        qs.sort();
        qs.showValue();
    }
    
}
