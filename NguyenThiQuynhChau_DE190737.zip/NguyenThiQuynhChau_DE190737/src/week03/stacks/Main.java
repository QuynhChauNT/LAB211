package week03.stacks;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Stacks stacks = new Stacks();
        
        while (true) {
            System.out.println("Choose an operation:" + '\n'
                    + " 1. Push" + '\n' 
                    + " 2. Pop" + '\n' 
                    + " 3. Get" + '\n' 
                    + " 4. Exit");
            int choice = scanner.nextInt();
            switch (choice) {
                case 1 -> {
                    System.out.print("Enter a value to push: ");
                    int number = scanner.nextInt();
                    stacks.push(number);
                }
                case 2 -> stacks.pop();
                case 3 -> stacks.get();
                case 4 -> {
                    System.out.println("Exiting program...");
                    scanner.close();
                    return;
                }
                default -> System.out.println("Invalid choice, try again.");
            }
        }
    }
}

