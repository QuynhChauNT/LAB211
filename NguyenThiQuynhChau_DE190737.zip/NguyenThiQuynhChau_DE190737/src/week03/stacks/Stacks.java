package week03.stacks;

import java.util.Stack;

public class Stacks {
    private Stack<Integer> stackInt;
    
    public Stacks() {
        stackInt = new Stack<>();
    }
    
    public void push(int n) {
        stackInt.push(n);
        System.out.println("Pushed: " + n);
    }
    
    public int pop() {
        if (!stackInt.isEmpty()) {
            int n = stackInt.pop();
            System.out.println("Popped: " + n);
            return n;
        } else {
            System.out.println("Stack is empty!");
            return -1;
        }
    }
    
    public int get() {
        if (!stackInt.isEmpty()) {
            int n = stackInt.peek();
            System.out.println("Top value: " + n);
            return n;
        } else {
            System.out.println("Stack is empty!");
            return -1;
        }
    }
}

