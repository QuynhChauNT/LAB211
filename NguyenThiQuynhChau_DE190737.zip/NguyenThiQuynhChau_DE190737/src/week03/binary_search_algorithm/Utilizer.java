package week03.binary_search_algorithm;

import java.util.Scanner;
public class Utilizer {
    static int addValueForSort(){
        Scanner scanner = new Scanner(System.in);
        while (true) {            
            try {
            System.out.println("Enter num element: ");
            int input = Integer.parseInt(scanner.next());
            return input;
            } catch (Exception e) {
                System.out.println("error");
            } 
        }
    }
    
     int addValue(){
        Scanner scanner = new Scanner(System.in);
        while (true) {            
            try {
            System.out.println("Enter num: ");
            int input = Integer.parseInt(scanner.next());
            return input;
            } catch (Exception e) {
                System.out.println("error");
            } 
        }
    }
    
    static int limitedNumber(){
        while (true) {            
            try {
                int n = addValueForSort();
                if (n>2) return n;
            } catch (Exception e) {
                
            }
            System.out.println("number less than 2");
        }
    }
}

