package week03.binary_search_algorithm;
public class Main {
    
    public static void main(String[] args) {
        BinarySearch binarySearch = new BinarySearch(Utilizer.limitedNumber());
        
        binarySearch.addValue();
        System.out.println("After sort: ");
        binarySearch.sort();
        binarySearch.showValue();
        
        int num = Utilizer.addValueForSort();
       
        int n = binarySearch.findNumber(num);
        System.out.println("Index for " + num+ ": " + n);
        
    }
}

