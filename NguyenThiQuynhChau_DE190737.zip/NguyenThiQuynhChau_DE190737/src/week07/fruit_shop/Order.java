package week07.fruit_shop;

import java.util.Hashtable;
import java.util.Map;

public class Order {
    private String customerName;
    Hashtable<Fruit, Integer> map;

    public Order(String customerName) {
        this.customerName = customerName;
        this.map = new Hashtable<>();
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void addFruit(Fruit fruit, int quantity){
        map.put(fruit, map.getOrDefault(fruit,0) + quantity);

    }
    public void display(){
        int total = 0;
        for(Map.Entry<Fruit, Integer> e : map.entrySet()){
            System.out.println("costomer: " + getCustomerName());
            total += e.getKey().getPrice() * e.getValue();
            System.out.println("product = " + e.getKey().getName() +" | quantity = " + e.getValue() + " | price = " + e.getKey().getPrice()+"$" +" | amount = " + (e.getKey().getPrice() * e.getValue()) + "$" );
        }
        System.out.println("Total: " + total);
    }
}
