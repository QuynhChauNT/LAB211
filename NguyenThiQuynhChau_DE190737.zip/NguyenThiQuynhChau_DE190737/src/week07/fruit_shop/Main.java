package week07.fruit_shop;

import java.util.Scanner;

public class Main{
    public static void main(String[] args) {
        Shopping shop = new Shopping();
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\nFRUIT SHOP SYSTEM");
            System.out.println("1. Create Fruit");
            System.out.println("2. View Orders");
            System.out.println("3. Shopping (for buyer)");
            System.out.println("4. Exit");
            System.out.print("Please choose an option: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> {
                    shop.createFruit();
                    break;
                }
                case 2 -> {
                    shop.viewOrders();
                    break;
                }
                case 3 -> {
                    shop.shopping();
                    break;
                }
                case 4 -> {
                    System.out.println("Exit!");
                    sc.close();
                    return;
                }
                default -> System.out.println("Invalid choice!");
            }
        }
    }
}
