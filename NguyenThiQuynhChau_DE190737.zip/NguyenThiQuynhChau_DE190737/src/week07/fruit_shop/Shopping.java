package week07.fruit_shop;

import java.util.ArrayList;
import java.util.Scanner;

public class Shopping{
    ArrayList<Fruit> fruits = new ArrayList<>();
    ArrayList<Order> orders = new ArrayList<>();
    Scanner sc = new Scanner(System.in);

    void createFruit(){
        while(true) {
            String id = Validation.getString("Enter id fruit: ");
            String name = Validation.getString("Enter name fruit: ");
            int price = Validation.getInt("Enter price fruit: ", 0, Integer.MAX_VALUE);
            int quantity = Validation.getInt("Enter quantity fruit: ", 0,  Integer.MAX_VALUE);
            String origin = Validation.getString("Enter origin: ");

            fruits.add(new Fruit(id, name, price, quantity, origin));
            System.out.println("Do you want to countinue (Y/N): ");
            String temp = sc.nextLine();
            if(temp.equalsIgnoreCase("N")) break;
        }
    }

    void viewOrders(){
        for(Order o : orders){
            o.display();
        }
    }

    void shopping(){
        System.out.println("List of fruit: ");
        for(int i = 0; i < fruits.size(); i++){
            System.out.println((i+1) + " " + fruits.get(i));
        }
        while (true) {
            System.out.println("select item: ");
            int item = sc.nextInt();
            Fruit select = fruits.get(item-1);
            System.out.println("you select: " + select.getName());
            int quantity = Validation.getInt("please input quantity: ", 0, select.getQuantity());
            String temp = Validation.getString("Do you want to order now (Y/N): ");
            if (temp.equalsIgnoreCase("Y")) {
                String name = Validation.getString("Enter your name: ");
                Order order = new Order(name);
                order.addFruit(select, quantity);
                orders.add(order);
                select.setQuantity(select.getQuantity() - quantity);
                System.out.println("Order placed successfully!");
                break;
            }
        }

    }

}
