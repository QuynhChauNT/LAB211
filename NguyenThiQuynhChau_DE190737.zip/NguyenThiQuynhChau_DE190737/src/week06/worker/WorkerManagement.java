package week06.worker;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class WorkerManagement {
    List<Worker> workers = new ArrayList<>();
    List<SalaryHistory> salaryHistories = new ArrayList<>();

    public boolean addWorker(Worker worker) throws Exception{
        if(worker == null){
            throw new Exception("Worker can be null.");
        }
        for (Worker w : workers){
            if(w.getId().equalsIgnoreCase(worker.getId())){
                throw new Exception("worker with the same ID already exit.");
            }

        }
        return workers.add(worker);
    }
    public void addWorker(){
        String id = Validation.getString("Enter id");
        String name = Validation.getString("Enter name");
        int age = Validation.getInt("Enter age",0);
        double salary = Validation.getDouble("Enter salary",0);
        String location = Validation.getString("Enter work location");


        try{
            Worker worker = new Worker(id,name,age,salary,location);
            if(addWorker(worker)){
                System.out.println("Worker add successfully.");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public boolean changeSalary(SalaryStatus status, String code, double amount) throws Exception {
        Worker worker = searchById(code);
        if (worker == null) {
            throw new Exception("Worker not exit.");
        }

        if ((status == SalaryStatus.UP) == (amount < worker.getSalary())) {
            throw new Exception("Error.");
        }

        worker.setSalary(amount);
        salaryHistories.add(new SalaryHistory(worker.getId(), worker.getName(), worker.getAge(), worker.getWorkLocation(), amount, status));
        return true;
    }
    public Worker searchById(String id){
        for(Worker w: workers){
            if (w.getId().equalsIgnoreCase(id)){
                return w;
            }
        }
        return null;
    }

    public List<SalaryHistory> getInfomationSalary(){
        salaryHistories.sort(Comparator.comparing(Worker::getId));
        return salaryHistories;
    }
}
