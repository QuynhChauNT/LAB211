package week06.worker;

enum SalaryStatus {
    UP, DOWN
}
public class SalaryHistory extends Worker{
//    private String workerId;
//    private String name;
//    private int age;
    private double salary;
    private SalaryStatus status;

    public SalaryHistory(String id, String name, int age, String location, double salary, SalaryStatus status) {

        super(id, name, age, location);
        this.salary = salary;
        this.status = status;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public SalaryStatus getStatus() {
        return status;
    }

    public void setStatus(SalaryStatus status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return super.toString() + String.format(" %-10.2f  %-8s ", getSalary(), getStatus());
    }
}
