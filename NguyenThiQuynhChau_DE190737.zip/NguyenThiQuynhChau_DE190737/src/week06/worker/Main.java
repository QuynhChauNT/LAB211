package week06.worker;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        WorkerManagement workerManagement = new WorkerManagement();
        while(true){
            System.out.println("============ Worker Manager ===========");
            System.out.println("1. Add worker.");
            System.out.println("2. Up salary.");
            System.out.println("3. Down salary.");
            System.out.println("4. Display Information salary.");
            System.out.println("5. Exit.");

            System.out.println("Enter your choice: ");
            int choice = sc.nextInt();

            switch (choice){
                case 1 -> {
                    workerManagement.addWorker();

                }
                case 2 -> {

                    System.out.println("----------UP Salary---------");
                    String code;
                    while (true) {
                        code = Validation.getString("Enter code");
                        if (workerManagement.searchById(code) != null) break;
                        System.out.println("Worker ID not exit. enter again.");
                    }
                    while(true){
                        double newSalary = Validation.getDouble("Enter new salary: ",0);
                        try{
                            if(workerManagement.changeSalary(SalaryStatus.UP,code,newSalary));
                            System.out.println("update successfully.");
                            break;
                        } catch (Exception e){
                            System.out.println(e.getMessage() + " The new salary must more than current salary. Enter again.");
                        }
                    }
                }
                case 3 -> {
                    System.out.println("----------Down Salary---------");
                    String code;
                    while (true) {
                        code = Validation.getString("Enter code: ");
                        if (workerManagement.searchById(code) != null) break;
                        System.out.println("Worker ID not exit. enter again.");
                    }
                    while (true) {
                        double newSalary = Validation.getDouble("Enter new salary: ", 0);
                        try {
                            if (workerManagement.changeSalary(SalaryStatus.DOWN, code, newSalary)) {
                                System.out.println("update successfully.");
                                break;
                            }
                        } catch (Exception e) {
                            System.out.println(e.getMessage() + " The new salary must less than current salary. Enter again.");
                        }
                    }
                }
                case 4 ->{
                    System.out.println("----------Display Information Salary---------");
                    List<SalaryHistory> salaryHistories = workerManagement.getInfomationSalary();
                    if(salaryHistories.isEmpty()){
                        System.out.println("list is empty");
                    } else {
                        salaryHistories.forEach(System.out::println);
                    }
                }
                case 5 -> {
                    System.out.println("Exit.");
                    sc.close();
                    return;
                }
                default -> System.out.println("Invalid input.Please try again.");
            }
        }
    }
}
