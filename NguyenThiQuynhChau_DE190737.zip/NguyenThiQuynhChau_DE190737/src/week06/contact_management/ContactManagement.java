package week06.contact_management;

import java.util.ArrayList;
import java.util.List;

public class ContactManagement {

    public boolean addContact(List<Contact> list, Contact contact){
        if (list.isEmpty()) {
            contact.setID(1);
        } else {
            contact.setID(list.getLast().getID() + 1);
        }
//
//        for(Contact c: list){
//            if(c.getID() == contact.getID());
//            return false;
//        }
        list.add(contact);
        return true;
    }

    public void displayAll(List< Contact > list){
        for(Contact c : list){
            System.out.println(c);
        }
    }

    public boolean deleteContact(List<Contact> list, Contact contact){
        return list.remove(contact);
    }

}
