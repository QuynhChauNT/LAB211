package week06.contact_management;

import java.util.ArrayList;
import java.util.List;

public class ContactManagement {

    public boolean addContact(List<Contact> list, Contact contact){
        if(contact == null) return false;
        int id = list.isEmpty() ? 1 : (list.getLast().getID() + 1);
        contact.setID(id);
        return list.add(contact);
    }

    public void displayAll(List< Contact > list){
        if (list.isEmpty()) System.out.println("List is empty.");
        for (Contact c : list){
            System.out.println(c);
        }
    }

    public boolean deleteContact(List<Contact> list, Contact contact){
        return list.remove(contact);
    }

}
