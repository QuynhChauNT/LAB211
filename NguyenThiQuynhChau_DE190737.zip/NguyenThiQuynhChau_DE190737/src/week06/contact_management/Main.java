package week06.contact_management;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Contact> list = new ArrayList<>();
        ContactManagement cm = new ContactManagement();
        while (true){
            System.out.println("=========Contact program=========");
            System.out.println("1. Add a contact");
            System.out.println("2. Display all contact");
            System.out.println("3. Delete a contact");
            System.out.println("4. Exit.");

            System.out.println("Enter your choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice){
                case 1 -> {
                    System.out.println("---------Add a Contact---------");
                    String fname = Validation.getString("Enter first name:");
                    String lname = Validation.getString("Enter last name:");
                    String group = Validation.getString("Enter group:");
                    String address = Validation.getString("Enter address:");
                    String phone = Validation.getPhone("Enter phone: ");

                    try {
                        Contact contact = new Contact(fname, lname, group, address, phone);
                        if (cm.addContact(list, contact)) {
                            System.out.println("add successfully.");
                        }
                    } catch (Exception e){
                        System.out.println("Failed to add contact." + e.getMessage());
                    }
                }
                case 2 -> {
                    System.out.println("---------Display all Contact---------");
                    cm.displayAll(list);
                }
                case 3 -> {
                    System.out.println("---------Delete a Contact---------");
                    if(list.isEmpty()){
                        System.out.println("List is empty");
                        return;
                    }
                    while (true) {
                        int id = Validation.getInt("Enter contact id need to delete: ");
                        Contact contact = null;
                        for (Contact c : list) {
                            if (c.getID() == id) {
                                contact = c;
                                break;
                            }
                        }
                        if (contact != null){
                            if(cm.deleteContact(list,contact)) {
                                System.out.println("Remove successfully.");
                                break;
                            }
                        } else {
                            System.out.println("Contact not found. Please enter a valid ID.");
                        }
                    }
                }
                case 4 -> {
                    return;
                }
                default -> System.out.println("Invalid choice. Enter again please.");
            }
        }
    }
}
