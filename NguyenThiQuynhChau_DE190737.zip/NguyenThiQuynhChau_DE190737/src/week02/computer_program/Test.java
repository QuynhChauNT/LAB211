package week02.computer_program;

import java.util.Scanner;

public class Test{
    public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            ComputerProgram computerProgram = new ComputerProgram();
            while (true) {
            System.out.println("========= Calculator Program =========");
            System.out.println("1. Normal Calculator");
            System.out.println("2. BMI Calculator");
            System.out.println("3. Exit");
            System.out.print("Please choose one option: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    computerProgram.runCalculator();
                    break;
                case 2:
                    computerProgram.runBMICalculator();
                    break;
                case 3:
                    System.out.println("Exiting program. Goodbye!");
                    sc.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
