package week02.caculate_perimeter_area;
public abstract class Shape {
   public abstract double getPerimeter();
   public abstract double getArea();
   public abstract void printResult();
}
