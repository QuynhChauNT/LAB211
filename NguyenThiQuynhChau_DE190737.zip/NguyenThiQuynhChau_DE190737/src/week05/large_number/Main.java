package week05.large_number;

public class Main {
    public static void main(String[] args) {
        BigData num1 = new BigData(Utilizer.getString("Enter first number"));
        BigData num2 = new BigData(Utilizer.getString("Enter second number"));
        BigData sum = num1.add(num2);
        BigData product = num1.multiply(num2);
        System.out.println("Sum: " + sum);
        System.out.println("Product: " + product);
    }
}
