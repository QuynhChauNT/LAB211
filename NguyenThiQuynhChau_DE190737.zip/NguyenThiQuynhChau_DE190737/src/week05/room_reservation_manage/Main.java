package week05.room_reservation_manage;

public class Main {
    public static void main(String[] args) {
        ReservationManagement reservationManagement = new ReservationManagement();
        reservationManagement.menu();
    }
}
