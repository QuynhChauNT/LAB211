package week05.room_reservation_manage;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class Validation {
    public static Scanner scanner = new Scanner(System.in);
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");


    public static String checkInputString() {
        while(true) {
            String result = scanner.nextLine();
            if (!result.isEmpty()) {
                return result;
            }else {
                System.err.println("String can't be empty");
                System.out.print("Enter again: ");
            }
        }
    }

    public static String checkInputString(String text) {
        System.out.println(text);
        while(true) {
            String result = scanner.nextLine();
            if (!result.isEmpty()) {
                return result;
            }else {
                System.err.println("String can't be empty");
                System.out.print("Enter again: ");
            }
        }
    }

    public static int checkInputInt() {
        while (true) {
            try {
                int result = Integer.parseInt(scanner.nextLine());
                if (result > 0) {
                    return result;
                }
                System.err.println("Can't be a negative number");
                System.out.print("Enter again: ");
            } catch (NumberFormatException e) {
                System.err.println("Please input integer");
                System.out.print("Enter again: ");
            }
        }
    }

    public static String checkInputID() {
        System.out.println("Enter reservation id: ");
        while(true) {
            String result = checkInputString();
            if(result.matches("\\d{6}")) {
                return result;
            }
            System.out.println("You have to enter 6 digits");
            System.out.print("Enter again: ");
        }
    }

    public static String checkInputName() {
        System.out.println("Enter reservation name: ");
        while(true) {
            String name = checkInputString();
            if(name.matches("[a-zA-Z ]+")) {
                return name;
            }
            System.out.println("Fullname just be entered by alphabet and blanks");
            System.out.print("Enter again: ");
        }
    }

    public static String checkInputPhoneNumber() {
        System.out.println("Enter phone: ");
        while(true) {
            String result = checkInputString();
            if(result.matches("\\d{12}")) {
                return result;
            }
            System.out.println("You have to enter 12 digits");
            System.out.print("Enter again: ");
        }
    }

    public static String checkInputRoomNumber() {
        System.out.println("Enter room number: ");
        while(true) {
            String result = checkInputString();
            if(result.matches("\\d{4}")) {
                return result;
            }
            System.out.println("You have to enter 4 digits");
            System.out.print("Enter again: ");
        }
    }

    public static LocalDate checkInputBookingDate() {
        System.out.println("Enter booking date (yyyy-MM-dd): ");
        while (true) {
            try {
                String bDate = checkInputString().trim();
                LocalDate bookingDate = LocalDate.parse(bDate, formatter);

                if (bookingDate.isAfter(LocalDate.now())) {
                    return bookingDate;
                }
                System.out.println("Booking date must be after today!");
            } catch (DateTimeParseException e) {
                System.out.println("Invalid format! Please enter again (yyyy-MM-dd): ");
            }
        }
    }

    public static LocalDate checkInputPickUpTime() {
        System.out.println("Enter pick up time: ");
        while (true) {
            try {
                String input = checkInputString().trim();
                LocalDate pickUpDate = LocalDate.parse(input, formatter);

                if (pickUpDate.isAfter(LocalDate.now())) {
                    return pickUpDate;
                }
                System.out.println("Pick-up date must be after today and before the booking date!");
            } catch (DateTimeParseException e) {
                System.out.println("Invalid format! Please enter again (yyyy-MM-dd): ");
            }
        }
    }

    public static LocalDate checkInputTime() {
        System.out.println("Enter pick up time: ");
        while (true) {
            try {
                String input = checkInputString().trim();
                LocalDate pickUpDate = LocalDate.parse(input, formatter);

                if (pickUpDate.isAfter(LocalDate.now())) {
                    return pickUpDate;
                }
                System.out.println("Pick-up date must be after today!");
            } catch (DateTimeParseException e) {
                System.out.println("Invalid format! Please enter again (yyyy-MM-dd): ");
            }
        }
    }
}
