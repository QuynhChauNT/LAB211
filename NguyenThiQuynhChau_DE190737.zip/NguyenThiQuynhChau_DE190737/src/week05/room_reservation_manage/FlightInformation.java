package week05.room_reservation_manage;

import java.time.LocalDate;

public class FlightInformation {
    private String flightNumber;
    private String seatNumber;
    private LocalDate timePickUp;

    public FlightInformation() {
        this.flightNumber = "";
        this.seatNumber = "";
        this.timePickUp = LocalDate.now();
    }

    public FlightInformation(String flightNumber, String seatNumber, LocalDate timePickUp) {
        this.flightNumber = flightNumber;
        this.seatNumber = seatNumber;
        this.timePickUp = timePickUp;
    }

    @Override
    public String toString() {
        return "FlightInformation{" + "flightNumber=" + flightNumber + ", seatNumber=" + seatNumber + ", timePickUp=" + timePickUp + '}';
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(String seatNumber) {
        this.seatNumber = seatNumber;
    }

    public LocalDate getTimePickUp() {
        return timePickUp;
    }

    public void setTimePickUp(LocalDate timePickUp) {
        this.timePickUp = timePickUp;
    }
}
