package week05.room_reservation_manage;

import java.time.LocalDate;
import java.util.ArrayList;

public class ReservationManagement {
    private ArrayList<Reservation> reservations;
    private ArrayList<FlightInformation> flights;

    public ReservationManagement() {
        this.reservations = new ArrayList<>();
        this.flights = new ArrayList<>();
    }

    public void addReservation() {
        String bookingID;
        while (true) {
            bookingID = Validation.checkInputID();
            boolean exists = false;
            for (Reservation reservation : this.reservations) {
                if (reservation.getBookingID().equals(bookingID)) {
                    System.out.println("ID already exists. Enter again.");
                    exists = true;
                    break;
                }
            }
            if (!exists) {
                break;
            }
        }
        String customerName = Validation.checkInputName();
        String phoneNumber = Validation.checkInputPhoneNumber();
        String roomNumber = Validation.checkInputRoomNumber();
        LocalDate dateTime = Validation.checkInputBookingDate();
        String flightInformation = Validation.checkInputString("Enter your flight number: ");
        Reservation reservation = new Reservation(bookingID, customerName, phoneNumber, roomNumber, dateTime, flightInformation);
        this.reservations.add(reservation);
    }

    public void addFlight() {
        String flightNumber = Validation.checkInputString("Enter your flight number: ");
        String seatNumber = Validation.checkInputString("Enter your seat number: ");
        LocalDate timePickUp = Validation.checkInputPickUpTime();
        FlightInformation flight = new FlightInformation(flightNumber, seatNumber, timePickUp);
        this.flights.add(flight);
    }

    public boolean deleteReservation(String id) {
        for (int i = 0; i < this.reservations.size(); i++) {
            if (this.reservations.get(i).getBookingID().equals(id)) {
                this.reservations.remove(i);
                return true;
            }
        }
        return false;
    }

    public boolean deleteFlight(String flightNumber) {
        for (int i = 0; i < this.flights.size(); i++) {
            if (this.flights.get(i).getFlightNumber().equals(flightNumber)) {
                this.flights.remove(i);
                return true;
            }
        }
        return false;
    }

    public void searchReservation(String id) {
        for (Reservation reservation : reservations) {
            if (reservation.getBookingID().equals(id)) {
                System.out.println(reservation);
            }
        }
    }

    public void searchNeededPickUpFlight(LocalDate time) {
        for (FlightInformation flight : flights) {
            if (flight.getTimePickUp().isAfter(time)) {
                System.out.println(flight);
            }
        }
    }

    public void showInfoReservation() {
        this.reservations.forEach(System.out::println);
    }
    public void showInfoFlight() {
        this.flights.forEach(System.out::println);
    }

    public void menu() {
        while (true) {
            System.out.println("-----Reservation Management-----");
            System.out.println("1. Room management");
            System.out.println("2. Flight management");
            System.out.println("3. Exit");
            System.out.println("Enter your choice: ");
            int choice = Validation.checkInputInt();

            switch (choice) {
                case 1 -> {
                    while (true) {
                        System.out.println("-----Room management-----");
                        System.out.println("1. Add room reservation");
                        System.out.println("2. Search room reservation");
                        System.out.println("3. Delete room reservation");
                        System.out.println("4. Show room reservation");
                        System.out.println("5. Exit");
                        System.out.println("Enter your choice: ");
                        int option = Validation.checkInputInt();

                        switch (option) {
                            case 1 -> this.addReservation();
                            case 2 -> this.searchReservation(Validation.checkInputString("Enter room id to check: "));
                            case 3 -> this.deleteReservation(Validation.checkInputString("Enter room id to delete: "));
                            case 4 -> this.showInfoReservation();
                            case 5 -> {
                                System.out.println("Exiting Room Management...");
                                break;
                            }
                            default -> System.out.println("Invalid choice! Enter again.");
                        }
                        if (option == 5) break;
                    }
                }

                case 2 -> {
                    while (true) {
                        System.out.println("-----Flight management-----");
                        System.out.println("1. Add flight reservation");
                        System.out.println("2. Search flight reservation");
                        System.out.println("3. Delete flight reservation");
                        System.out.println("4. Show flight reservation");
                        System.out.println("5. Exit");
                        System.out.println("Enter your choice: ");
                        int option = Validation.checkInputInt();

                        switch (option) {
                            case 1 -> this.addFlight();
                            case 2 -> this.searchNeededPickUpFlight(Validation.checkInputTime());
                            case 3 -> this.deleteFlight(Validation.checkInputString("Enter flight number: "));
                            case 4 -> this.showInfoFlight();
                            case 5 -> {
                                System.out.println("Exiting Flight Management...");
                                break;
                            }
                            default -> System.out.println("Invalid choice! Enter again.");
                        }
                        if (option == 5) break;
                    }
                }

                case 3 -> {
                    System.out.println("Exiting program...");
                    return;
                }

                default -> System.out.println("Invalid choice! Enter again.");
            }
        }
    }
}
