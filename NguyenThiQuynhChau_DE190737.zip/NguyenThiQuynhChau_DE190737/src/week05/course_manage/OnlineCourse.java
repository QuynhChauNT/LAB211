package week05.course_manage;

import java.text.ParseException;

public class OnlineCourse extends Course{
    private String platform;
    private String instructors;
    private String note;

    public OnlineCourse() {
        this.platform = null;
        this.instructors = null;
        this.note = null;
    }

    public OnlineCourse(String courseId, String name, int credits, String platform, String instructors, String note) {
        super(courseId, name, credits);
        this.platform = platform;
        this.instructors = instructors;
        this.note = note;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getInstructors() {
        return instructors;
    }

    public void setInstructors(String instructors) {
        this.instructors = instructors;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }


//    @Override
    public void inputAll(String courseId, String name, int credits, String platform, String instructors, String note) {
        super.inputAll(courseId, name, credits);
        this.platform = platform;
        this.instructors = instructors;
        this.note = note;
    }

    @Override
    public String toString() {
        return super.toString() + "OnlineCourse{" +
                "platform='" + platform + '\'' +
                ", instructors='" + instructors + '\'' +
                ", note='" + note + '\'' +
                '}';
    }
}
