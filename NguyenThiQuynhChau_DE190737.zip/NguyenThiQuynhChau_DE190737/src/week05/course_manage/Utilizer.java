package week05.course_manage;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.Scanner;

public class Utilizer {

    private static final Scanner scanner = new Scanner(System.in);

    public static int getInt() {
        return getInt(null, Integer.MIN_VALUE, Integer.MAX_VALUE);
    }

    public static int getInt(int minRange, int maxRange) {
        return getInt(null, minRange, maxRange);
    }

    public static int getInt(String msg) {
        return getInt(msg, 1, Integer.MAX_VALUE);
    }

    public static int getInt(String msg, int minRange, int maxRange) {
        if (minRange > maxRange) {
            int temp = minRange;
            minRange = maxRange;
            maxRange = temp;
        }

        int value = Integer.MIN_VALUE;

        do {
            try {
                if (msg != null) {
                    System.out.print(msg);
                }

                value = Integer.parseInt(scanner.nextLine());
                if(value < 1) System.err.println("Credits must greater than 0");
            } catch (NumberFormatException e) {
                System.err.println("Credits is greater than 0. Please enter again...");
            }
        } while (value < minRange || value > maxRange);

        return value;
    }

    public static String getString(String msg, String pattern) {
        String value = null;

        do {
            value = getString(msg);
        } while (!value.matches(pattern));

        return value;
    }

    public static String getString(String msg) {
        String value;

        while (true) {
            if (msg != null) {
                System.out.print(msg);
            }

            value = scanner.nextLine().replaceAll("\\s+", " ").trim();

            if (!value.isEmpty() && !value.isBlank()) {
                break;
            }

            System.err.println("Can not empty. Please enter again...");
        }

        return value;
    }
    public static double getDouble(String message, double min, double max) {
        double input;
        while (true) {
            System.out.print(message);
            try {
                input = Double.parseDouble(scanner.nextLine());
                if (input >= min && input <= max) {
                    break;
                }
                System.out.println("Input must be between " + min + " and " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
        return input;
    }

//    public static Date checkValidDate(String msg, String dateStr) {
//        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
//        sdf.setLenient(false);
////        return sdf.parse(dateStr);
//        while (true) {
//            try {
//                System.out.println(msg);
//                String inputDate = scanner.nextLine().trim();
//                Date r = Date.parse(inputDate, sdf);
//                if(r.after(dateStr)){
//
//                }
//                return sdf.parse(dateStr);
//            } catch (ParseException e) {
//                System.out.println("Định dạng ngày không hợp lệ. Vui lòng nhập lại.");
//                dateStr = scanner.nextLine().trim();
//
//            }
//        }
//    }

    public static LocalDate getDate(String msg, LocalDate minDate){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        while(true){
            try{
                System.out.println(msg);
                String inputDate = scanner.nextLine().trim();
                LocalDate date = LocalDate.parse(inputDate, formatter);
                if(minDate == null || date.isAfter(minDate)) {
                    return date;
                } else {
                    System.err.println("Data input is invalid, date must be after " + minDate.format(formatter));
                }
            }catch (DateTimeParseException e){
                System.err.println("Input unvalid. Please enter the date in format dd/MM/yyyy.");
            }
        }

    }

    public static boolean getBoolean(String message) {
        while (true) {
            System.out.print(message);
            String input = scanner.nextLine().trim().toLowerCase();
            if (input.equals("true")) {
                return true;
            } else if (input.equals("false")) {
                return false;
            }
            System.out.println("Invalid input. Please enter true or false.");
        }
    }

    public static boolean checkPattern(String id, String pattern){
        return id.matches(pattern);
    }


    public static String checkInput(String msg){
        String input;
        while(true){
            try {
                System.out.print(msg);
                input = scanner.nextLine().trim();
                if (input.equalsIgnoreCase("O") || input.equalsIgnoreCase("F")) {
                    return input;
                }
                System.out.println("data input is invalid");
            } catch (Exception e) {
                System.out.println("data input is invalid");
            }
        }
    }

    public static String checkInput1(String input){
        while(true){
            input = scanner.nextLine().trim();
            if(input.equalsIgnoreCase("o") || input.equalsIgnoreCase("f") || input.equalsIgnoreCase("a")){
                break;
            }
            System.out.println("data input is invalid");
        }
                return input;
    }

    public static boolean yesOrNo(String input){
        while(true){
            if(input.equalsIgnoreCase("y")) return true;
            if (input.equalsIgnoreCase("n")) return false;
            System.out.println("data input is invalid");
        }
    }
}

