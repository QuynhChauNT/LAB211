package week05.course_manage;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        CourseManagement cm = new CourseManagement();
//        OnlineCourse onlineCourse1 = new OnlineCourse();
//        onlineCourse1.inputAll("prj302","java web", 3, "windown", "le vo","su25" );
//    cm.
        while (true) {
            System.out.println("\n********* COURSE MANAGEMENT **********");
            System.out.println("1. Add online course/ offline course");
            System.out.println("2. Update course");
            System.out.println("3. Delete course)");
            System.out.println("4. Print all / online course / offline course");
            System.out.println("5. Search information base on course name");
            System.out.println("6. Exit");

            String choice = Utilizer.getString("Enter your choice: ");

            switch (choice) {
                case "1" -> {
                    System.out.println("****** Add new course ******");
                    cm.addCourse();
                    break;
                }
                case "2" -> {
                    System.out.println("****** Update course ******");
                    System.out.println("Course ID: ");
                    String id = sc.nextLine();
                    cm.updateByID(id);
                    break;
                }
                case "3" -> {
                    System.out.println("******** Delete course ********");
                    System.out.println("Course ID: ");
                    String deleteID = sc.nextLine();
                    cm.deleteByID(deleteID);
                    break;
                }
                case "4" -> {
                    System.out.println("Do you want to print all (A), online course (O) or offline course (F): ");
                    String a = sc.nextLine();
                    Utilizer.checkInput1(a);
                    cm.show(a);
                    break;
                }
                case "5" -> {
                    System.out.println("******* Searching ***********");
                    System.out.println("Course ID: ");
                    String b = sc.nextLine();

                    System.out.println(cm.searchByID(b));
                    break;
                }

                case "6" -> {
                    System.out.println("Exit.");
                    sc.close();
                    return;
                }
                default ->
                    System.out.println("Invalid choice. Please choose again.");
            }
        }
    }

}
