package week05.course_manage;

import java.util.Date;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        CourseManagement cm = new CourseManagement();
//        OnlineCourse onlineCourse = new OnlineCourse();
//    cm.
        while (true) {
            System.out.println("\n********* COURSE MANAGEMENT **********");
            System.out.println("1. Add online course/ offline course");
            System.out.println("2. Update course");
            System.out.println("3. Delete course)");
            System.out.println("4. Print all / online course / offline course");
            System.out.println("5. Search information base on course name");
            System.out.println("6. Exit");
            System.out.print("You choose: ");

            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> {
                    System.out.println("****** Add new course ******");
                    Scanner scanner = new Scanner(System.in);
                    System.out.println("--------------------------------");
                    System.out.print("Online (O) or Offline (F): ");
                    String input = Utilizer.checkInput(scanner.nextLine());
//                cm.addCourse(input);
                    System.out.println("enter id");
                    String courseID = Utilizer.getString(scanner.nextLine());
//sc.nextLine(); 
                    System.out.println("enter name");
                    String name = Utilizer.getString(scanner.nextLine());
                    System.out.println("enter credits:");
                    int credits = Utilizer.getInt(scanner.nextLine());

                    if (input.equalsIgnoreCase("O")) {
                        System.out.println("enter platform:");
                        String platform = Utilizer.getString(scanner.nextLine());
                        System.out.println("enter instructor:");
                        String instructors = Utilizer.getString(scanner.nextLine());
                        System.out.println("enter note:");
                        String note = Utilizer.getString(scanner.nextLine());
                        cm.addCourse(new OnlineCourse(courseID, name, credits, platform, instructors, note));
                    } else {
                        System.out.println("enter begin:");
                        Date begin = Utilizer.checkValidDate(scanner.nextLine());
                        Date end;
                        while (true) {
                            System.out.println("enter end:");
                            end = Utilizer.checkValidDate(scanner.nextLine());
                            if (end.after(begin)) {
                                break;
                            } else {
                                System.out.println("end must be after begin.");
                            }
                        }
                        System.out.println("enter campus:");
                        String campus = Utilizer.getString(scanner.nextLine());
                        cm.addCourse(new OfflineCourse(courseID, name, credits, begin, end, campus));
                    }
                    break;
                }
                case 2 -> {
                    System.out.println("****** Update course ******");
                    System.out.println("Course ID: ");
                    String id = sc.nextLine();
                    System.out.println("*** Search results ***\n" + cm.searchByID(id));

                    System.out.println("*** Updating ***");
                    System.out.println("Note: Enter empty if you don't want to change it.");
                    cm.updateByID(id);
                    break;
                }
                case 3 -> {
                    System.out.println("Course ID: ");
                    String deleteID = sc.nextLine();
                    cm.searchByID(deleteID);
                    cm.deleteByID(deleteID);
                    break;
                }
                case 4 -> {
                    System.out.println("Do you want to print all (A), online course (O) or offline course (F): ");
                    String a = sc.nextLine();
                    Utilizer.checkInput1(a);
                    cm.show(a);
                    break;
                }
                case 5 -> {
                    System.out.println("******* Searching ***********");
                    System.out.println("Course ID: ");
                    String b = sc.nextLine();

                    System.out.println(cm.searchByID(b));
                    break;
                }

                case 6 -> {
                    System.out.println("Exit.");
                    sc.close();
                    return;
                }
                default ->
                    System.out.println("Lựa chọn không hợp lệ. Vui lòng nhập lại.");
            }
        }
    }

}
