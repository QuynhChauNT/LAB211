package week05.course_manage;


import java.time.LocalDate;
import java.util.Date;

public class OfflineCourse extends Course{
    private LocalDate begin;
    private LocalDate end;
    private String campus;

    public OfflineCourse() {
        this.begin = null;
        this.end = null;
        this.campus = null;
    }

    public OfflineCourse(String courseId, String name, int credits, LocalDate begin, LocalDate end, String campus) {
        super(courseId, name, credits);
        this.begin = begin;
        this.end = end;
        this.campus = campus;
    }

    public LocalDate getBegin() {
        return begin;
    }

    public void setBegin(LocalDate begin) {
        this.begin = begin;
    }

    public LocalDate getEnd() {
        return end;
    }

    public void setEnd(LocalDate end) {
        this.end = end;
    }

    public String getCampus() {
        return campus;
    }

    public void setCampus(String campus) {
        this.campus = campus;
    }

    public void inputAll(String courseId, String name, int credits, LocalDate begin, LocalDate end, String campus) {
        super.inputAll(courseId, name, credits);
        this.begin = begin;
        this.end = end;
        this.campus = campus;
    }

    @Override
    public String toString() {
        return super.toString() + "OfflineCourse{" +
                "begin=" + begin +
                ", end=" + end +
                ", campus='" + campus + '\'' +
                '}';
    }
}
