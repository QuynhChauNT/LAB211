package week05.course_manage;

import javax.xml.transform.Source;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CourseManagement {
    private List<OnlineCourse> onlineCourseList = new ArrayList<>();
    private List<OfflineCourse> offlineCourses = new ArrayList<>();
    private ArrayList<Course> courseArrayList;

    private boolean checkExitsCourse (String id){
        for(Course c : courseArrayList){
            if(c.getCourseId().equalsIgnoreCase(id))
                return false;
        }
        return true;
    }

    Scanner sc = new Scanner(System.in);


    public CourseManagement() {
        this.courseArrayList = new ArrayList<>();
    }

    public void addCourse() {
        String choice = Utilizer.checkInput("Enter online/offline to add (o/f):  ");
        switch(choice) {
            case "o" -> {
                OnlineCourse onlineCourse = new OnlineCourse();
                System.out.println("----- add online course -----");
                System.out.println("enter id course: ");
                String id = null;
                while (true) {
                    id  = sc.nextLine();
                    if(checkExitsCourse(id)){
                        break;
                    }
                    System.err.println("Data input is invalid, ID must be unique");
                }
                String name = Utilizer.getString("Enter course name: ");
                int credit = Utilizer.getInt("Enter credits: ");
                String platform = Utilizer.getString("Enter platform: ");
                String intructor = Utilizer.getString("Enter instructor: ");
                String note = Utilizer.getString("Enter note: ");

                onlineCourse.inputAll(id, name, credit, platform, intructor, note);
                this.courseArrayList.add(onlineCourse);
                this.onlineCourseList.add(onlineCourse);
                System.out.println("Add successful");
            }
            case "f" -> {
                OfflineCourse offlineCourse = new OfflineCourse();
                System.out.println("----- add offline course -----");
                String id;
                while (true) {
                    id = Utilizer.getString("Enter id course: ");
                    if(checkExitsCourse(id)){
                        break;
                    }
                    System.err.println("Data input is invalid, ID must be unique");
                }
                String name = Utilizer.getString("Enter course name: ");
                int credit = Utilizer.getInt("Enter credits: ");
                LocalDate begin = Utilizer.getDate("Enter begin: ", null);
                LocalDate end;
                while (true){
                    try{
                        end = Utilizer.getDate("Enter end: ", begin);
                        if(end.isAfter(begin)) break;
                    } catch (DateTimeParseException e) {
                        System.err.println("Data input is invalid, end must be after begin");
                    }
                }
                String campus = Utilizer.getString("Enter campus: ");
                offlineCourse.inputAll(id, name, credit, begin, end, campus);
                this.courseArrayList.add(offlineCourse);
                this.offlineCourses.add(offlineCourse);
                System.out.println("Add successful");
            }
            default -> {
                System.out.println("Data input is invalid");
            }
        }
    }

    public void updateByID(String id) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        Course update = searchByID(id);
        System.out.println("*******Search result********");
        System.out.println(update.toString());
        System.out.println("********Updating***********");
        System.out.println("Note: Enter empty if you don't want to change it.");

        System.out.println("Course ID: ");
        String newID = sc.nextLine().trim();
        if (!newID.isEmpty()) {
            update.setCourseId(newID);
        }

        System.out.print("Course name: ");
        String newName = sc.nextLine().trim();
        if (!newName.isEmpty()) {
            update.setName(newName);
        }

        System.out.print("Credits: ");
        String newCredits = sc.nextLine().trim();
        if (!newCredits.isEmpty()) {
            try {
                update.setCredits(Integer.parseInt(newCredits));
            } catch (NumberFormatException e) {
                System.out.println("Invalid credit number. Must be an integer.");
            }
        }

        boolean isOnline = onlineCourseList.stream()
                .anyMatch(course -> course.getCourseId().equals(update.getCourseId()));
        boolean isOffline = offlineCourses.stream()
                .anyMatch(course -> course.getCourseId().equals(update.getCourseId()));

        if (isOnline) {
            OnlineCourse online = (OnlineCourse) update;
            System.out.print("Platform: ");
            String newPlatform = sc.nextLine().trim();
            if (!newPlatform.isEmpty()) {
                online.setPlatform(newPlatform);
            }


            System.out.print("Instructors: ");
            String newInstructors = sc.nextLine().trim();
            if (!newInstructors.isEmpty()) {
                online.setInstructors(newInstructors);
            }

            System.out.print("Note: ");
            String newNode = sc.nextLine().trim();
            if (!newNode.isEmpty()) {
                online.setInstructors(newNode);
            }
        } else if (isOffline) {
            OfflineCourse offline = (OfflineCourse) update;

            System.out.print("Begin (dd/MM/yyyy): ");
            String beginDateStr = (sc.nextLine().trim());
            if (!beginDateStr.isEmpty()) {
                try {
                    offline.setBegin(LocalDate.parse(beginDateStr, formatter));
                } catch (DateTimeParseException  e) {
                    System.out.println("Invalid date format. Please enter in dd-MM-yyyy format.");
                }
            }

            System.out.print("End: ");
            String endDateStr = sc.nextLine().trim();
            if (!endDateStr.isEmpty()) {
                try {
                    offline.setEnd(LocalDate.parse(endDateStr, formatter));
                } catch (DateTimeParseException e) {
                    System.out.println("Invalid date format. Please enter in dd-MM-yyyy format.");
                }
            }

            System.out.print("Campus: ");
            String newCampus = sc.nextLine().trim();
            if (!newCampus.isEmpty()) {
                offline.setCampus(newCampus);
            }
        }
        System.out.println("Updated successfully");
    }

    public Course searchByID(String id){
        while (true) {
            for (Course c : courseArrayList) {
                if (c.getCourseId().equalsIgnoreCase(id))
                    return c;
            }
            String temp;
            do {
                System.out.println("No data found, do you want to find again? (Y/N): ");
                temp = sc.nextLine();
            } while (Utilizer.yesOrNo(temp));
        }
    }

    public void deleteByID(String id){
        Course delete = searchByID(id);
        this.courseArrayList.remove(delete);
        System.out.println("Remove succeccfully.");
    }

     public void show(String str){
        if(str.equalsIgnoreCase("a")){
            this.courseArrayList.forEach(System.out::println);
        } else if (str.equalsIgnoreCase("o")) {
            this.onlineCourseList.forEach(System.out::println);
        } else {
            this.offlineCourses.forEach(System.out::println);
        }
     }

//     public ArrayList<Course> searchByCourseName(String courseName){
//         ArrayList<Course> list = new ArrayList<>();
//         for(Course c : list){
//             if(c.getName().equalsIgnoreCase(courseName))
//                 list.add(c);
//         }
//         if(list.isEmpty()) System.out.println("cannot find course.");
//         return list;
//     }

}
