package week05.course_manage;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class CourseManagement {
    private ArrayList<Course> courseArrayList;
    Scanner sc = new Scanner(System.in);


    public CourseManagement() {
        this.courseArrayList = new ArrayList<>();
    }

    public void addCourse(Course course) {
        this.courseArrayList.add(course);

    }

    public void updateByID(String id){
//        ArrayList<OnlineCourse> course = searchByID(id);
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

        for(Course c : courseArrayList) {
//            Course course = courseArrayList.get(i);
            if(c.getCourseId().equalsIgnoreCase(id)) {
                System.out.print("Course ID: ");
                String newCourseID = sc.nextLine().trim();
                if (!newCourseID.isEmpty()) {
//                courseArrayList.get(i).setCourseId(newCourseID);
                    c.setCourseId(newCourseID);
                }

                System.out.print("Course name: ");
                String newName = sc.nextLine().trim();
                if (!newName.isEmpty()) {
                    c.setName(newName);
                }

                System.out.print("Credits: ");
                String newCredits = sc.nextLine().trim();
                if (!newCredits.isEmpty()) {
                    c.setCredits(Integer.parseInt(newCredits));
                }

                if (c instanceof OnlineCourse) {
//                    ArrayList<OnlineCourse> on = searchByID(id);
                    OnlineCourse olc = (OnlineCourse) c;

                    System.out.print("Platform: ");
                    String newPlatform = sc.nextLine().trim();
                    if (!newPlatform.isEmpty()) {
                        olc.setPlatform(newPlatform);
                    }


                    System.out.print("Instructors: ");
                    String newInstructors = sc.nextLine().trim();
                    if (!newInstructors.isEmpty()) {
                        olc.setInstructors(newInstructors);
                    }

                    System.out.print("Note: ");
                    String newNode = sc.nextLine().trim();
                    if (!newNode.isEmpty()) {
                        olc.setNote(newNode);
                    }
                } else if (c instanceof OfflineCourse) {

                    System.out.print("Begin: ");
                    String beginDateStr = sc.nextLine().trim();
                    if (!beginDateStr.isEmpty()) {
                        try {
                            ((OfflineCourse) c).setBegin(sdf.parse(beginDateStr));
                        } catch (ParseException e) {
                            System.out.println("Invalid date format. Please enter in dd-MM-yyyy format.");
                        }
                    }

                    System.out.print("End: ");
                    String endDateStr = sc.nextLine().trim();
                    if (!endDateStr.isEmpty()) {
                        try {
                            ((OfflineCourse) c).setEnd(sdf.parse(endDateStr));
                        } catch (ParseException e) {
                            System.out.println("Invalid date format. Please enter in dd-MM-yyyy format.");
                        }
                    }

                    System.out.print("Campus: ");
                    String newNode = sc.nextLine().trim();
                    if (!newNode.isEmpty()) {
                        ((OfflineCourse) c).setCampus(newNode);
                    }
                }
            }
        }

        System.out.println("Updated successfully");
    }
    public Course searchByID(String id){
//        ArrayList<OnlineCourse> list = new ArrayList<>();
        while (true) {
            for (Course c : courseArrayList) {
                if (c.getCourseId().equalsIgnoreCase(id))
                    return c;
            }
            String temp;
            do {
                System.out.println("No data found, do you want to find again? (Y/N): ");
                temp = sc.nextLine();
            } while (Utilizer.yesOrNo(temp));
//        return list;
        }
    }

    public void deleteByID(String id){
        this.courseArrayList.removeIf(courseArrayList -> courseArrayList.getCourseId().equalsIgnoreCase(id));
    }

     public void show(String str){
        if(str.equalsIgnoreCase("a")){
            this.courseArrayList.forEach(System.out::println);
        } else if (str.equalsIgnoreCase("o")) {
            for(Course c : courseArrayList){
                if(c instanceof OnlineCourse){
                    System.out.println(c);
                }
            }
        } else {
            for(Course c : courseArrayList){
                if(c instanceof OfflineCourse){
                    System.out.println(c);
                }
            }
        }
//         this.courseArrayList.forEach(System.out::println);
     }

//     public ArrayList<Course> searchByCourseName(String courseName){
//         ArrayList<Course> list = new ArrayList<>();
//         for(Course c : list){
//             if(c.getName().equalsIgnoreCase(courseName))
//                 list.add(c);
//         }
//         if(list.isEmpty()) System.out.println("cannot find course.");
//         return list;
//     }

}
