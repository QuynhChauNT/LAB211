package week05.course_manage;

public class Course {
    private String courseId;
    private String name;
    private int credits;

    public Course() {
        this.courseId = null;
        this.name = null;
        this.credits = 0;
    }

    public Course(String courseId, String name, int credits) {
        this.courseId = courseId;
        this.name = name;
        this.credits = credits;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    public void inputAll(String id, String name, int credits){
        this.courseId = id;
        this.name = name;
        this.credits = credits;
    }
    @Override
    public String toString() {
        return "Course{" +
                "courseId='" + courseId + '\'' +
                ", name='" + name + '\'' +
                ", credits=" + credits +
                '}';
    }
}
