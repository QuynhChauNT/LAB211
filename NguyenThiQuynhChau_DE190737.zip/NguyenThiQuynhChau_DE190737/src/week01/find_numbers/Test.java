package week01.find_numbers;

public class Test extends Menu{
    EquationSolve equationSolver;

    public Test(String title, String[] options) {
        super(title, options);
        this.equationSolver = new EquationSolve();
    }

    @Override
    public void execute(int choice) {
        switch (choice) {
            case 1 -> equationSolver.calculateSuperlativeEquation();
            case 2 -> equationSolver.calculateQuadraticEquation();
            case 3 -> {
                System.out.println("Exiting...");
                stop();
            }
            default -> System.out.println("Invalid selection");
        }
    }

    public static void main(String[] args) {
        String[] options ={
                "Calculate Superlative Equation",
                "Calculate Quadratic Equation",
                "Exit"
        };
        new Test("========== Equation Program ==========", options).run();
    }
}


