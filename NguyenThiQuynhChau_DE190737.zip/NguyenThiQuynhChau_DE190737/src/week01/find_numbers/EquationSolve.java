package week01.find_numbers;

import java.util.Scanner;

public class EquationSolve {
    public void calculateSuperlativeEquation() {
         System.out.println("----- Calculate Equation -----");
         double a = checkInputDouble("Enter A: ");
         double b = checkInputDouble("Enter B: ");

        if (a != 0) {
            double x = -b/a;
            System.out.println("Solution: x = " +x);
        } else {
            System.out.println("Invalid equation! Coefficient A must not be 0.");
        }
        checkNumberProperties(a, b);
    }
    private double checkInputDouble(String prompt) {
        Scanner input = new Scanner(System.in);
        double result;
        while (true) {
            try {
                System.out.print(prompt);
                result = Double.parseDouble(input.nextLine());
                if (result > 0) {
                    return result;
                }
                System.err.println("Can't be a negative number");
            } catch (NumberFormatException e) {
                System.err.println("Please input a valid double");
            }
        }
    }

     public void calculateQuadraticEquation() {
        System.out.println("----- Calculate Quadratic Equation -----");
        double a = checkInputDouble("Enter A: ");
        double b = checkInputDouble("Enter B: ");
        double c = checkInputDouble("Enter C: ");

        if (a != 0) {
            double delta = (b*b) - (4*a*c);
            if (delta > 0) {
                double x1 = (-b + Math.sqrt(delta)) / (2 * a);
                double x2 = (-b - Math.sqrt(delta)) / (2 * a);
                System.out.println("Solution: x1 = " + x1 + " and x2 = " + x2);
            } else if (delta == 0) {
                double x = -b / (2 * a);
                System.out.println("Solution: x = " + x);
            } else {
                System.out.println("No real solution.");
            }
        }
        checkNumberProperties(a, b, c);
    }

    public void checkNumberProperties(double... numbers) {
        System.out.print("Odd Number(s): ");
        for (double num : numbers) {
            if ((int) num % 2 != 0) {
                System.out.print(num + " ");
            }
        }

        System.out.print("\nNumber is Even: ");
        for (double num : numbers) {
            if ((int) num % 2 == 0) {
                System.out.print(num + " ");
            }
        }

        System.out.print("\nNumber is Perfect Square: ");
        for (double num : numbers) {
            if (num >= 0 && Math.sqrt(num) == (int) Math.sqrt(num)) {
                System.out.print(num + " ");
            }
        }
        System.out.println();
    }

}
