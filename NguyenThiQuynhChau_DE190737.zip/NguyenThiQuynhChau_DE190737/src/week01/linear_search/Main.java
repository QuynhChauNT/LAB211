package week01.linear_search;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of array: ");
        int size = sc.nextInt();
        System.out.println("Find number: ");
        int num = sc.nextInt();
        LinearSearch linearSearch = new LinearSearch(size);
        linearSearch.addValue(size);
        linearSearch.showValue();
        System.out.println("Found " + num + " at index: " + linearSearch.searchValue(num));
    }
}
