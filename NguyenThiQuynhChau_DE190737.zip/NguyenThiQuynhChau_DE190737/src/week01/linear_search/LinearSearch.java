package week01.linear_search;

import java.util.Random;
class LinearSearch {
    private int[] array;

    public LinearSearch(int size) {
        this.array = new int[size];
    }

    void addValue(int size){
        while (true) {
            if (size > 0) {
                break;
            } else {
                System.out.print("Invalid input. Please enter a positive integer: ");
            }
        }

        Random random = new Random();
        array = new int[size];
        for (int i = 0; i < array.length; i++) {
            array[i] = random.nextInt(array.length);
        }
    }

    void showValue(){
        System.out.print("The Array: ");
        for (int num : array) {
            System.out.print(num + "\t");
        }
        System.out.println();
    }

    int searchValue(int x){
        for (int i = 0; i < array.length; i++) {
            if (array[i] == x) {
                return i;
                
            }
        }
        return -1;
    }
}
