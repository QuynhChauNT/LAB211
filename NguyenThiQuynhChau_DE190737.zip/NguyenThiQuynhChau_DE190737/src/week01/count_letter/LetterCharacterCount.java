package week01.count_letter;

import java.util.HashMap;
import java.util.Map;

public class LetterCharacterCount {
    private String input;

    public LetterCharacterCount(String input) {
        this.input = input;
    }
    
    Map<String, Integer> countWord(String x){
        Map<String, Integer> countW = new HashMap<>();
        String[] words = x.split("\\s+");
        for (String word : words){
            word = word.toLowerCase();
            countW.put(word, countW.getOrDefault(word, 0) + 1);
        }
        return countW;
    }

    Map<Character,Integer> countCharacter(String x){
        Map<Character, Integer> countC = new HashMap<>();
        for (char c : x.toCharArray()){
            if(Character.isLetter(c)){
                c = Character.toLowerCase(c);
                countC.put(c, countC.getOrDefault(c, 0) + 1);
            }
        }
        return countC;
    }
    
    void displayWord(Map<String, Integer> wordCount) {
        System.out.println("Word Count:");
        wordCount.forEach((word, count) -> System.out.println(word + " = " + count));
    }

    void displayCharacter(Map<Character, Integer> charCount) {
        System.out.println("Character Count:");
        charCount.forEach((character, count) -> System.out.println(character + " = " + count));
    }
}

