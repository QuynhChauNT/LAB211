package week01.count_letter;

import java.util.Map;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter a string: ");
        String input = sc.nextLine();
        LetterCharacterCount lcc = new LetterCharacterCount(input);
        Map<String,Integer> wordCount = lcc.countWord(input);
        lcc.displayWord(wordCount);
        Map<Character,Integer> characterCount = lcc.countCharacter(input);
        lcc.displayCharacter(characterCount);
    }
}
